/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package main;

/**
 *
 * @author CSU23
 */
public class Main {
    public static void main(String[] args) {
        
        Guitarra guitarra = new Guitarra("marron", 6, false, "madera");
        Perro perro = new Perro("piel", "Golden Retriever", true, "Max");

        
        System.out.println("Color de la guitarra: " + guitarra.getColor());
        System.out.println("Numero de cuerdas: " + guitarra.getNumCuerdas());
        System.out.println("Material de la guitarra: " + guitarra.getMaterial());


        System.out.println("Nombre del perro: " + perro.getNombre());
        System.out.println("Que raza es el perro: " + perro.getRaza());
        System.out.println("El color del perro es: " + perro.getColor());

        

        
    }
}
