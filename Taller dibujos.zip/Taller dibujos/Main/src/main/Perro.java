/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author CSU23
 */
public class Perro {
    

    
    private String color;
    private String raza;
    private boolean tieneCola;
    private String nombre;

    
    public Perro(String color, String raza, boolean tieneCola, String nombre) {
        this.color = color;
        this.raza = raza;
        this.tieneCola = tieneCola;
        this.nombre = nombre;
    }

    
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public boolean isTieneCola() {
        return tieneCola;
    }

    public void setTieneCola(boolean tieneCola) {
        this.tieneCola = tieneCola;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    
    public void ladrar() {
        System.out.println("¡Guau guau!");
    }

    public void dormir() {
        System.out.println("Zzzz...");
    }

    public void saludar() {
        System.out.println("¡Hola! Soy " + nombre);
    }
}

