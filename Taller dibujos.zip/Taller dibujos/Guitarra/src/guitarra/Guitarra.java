/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package guitarra;


public class Guitarra {
    
    private String color;
    private int numCuerdas;
    private boolean electrica;
    private String material;

    
    public Guitarra(String color, int numCuerdas, boolean electrica, String material) {
        this.color = color;
        this.numCuerdas = numCuerdas;
        this.electrica = electrica;
        this.material = material;
    }

    
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getNumCuerdas() {
        return numCuerdas;
    }

    public void setNumCuerdas(int numCuerdas) {
        this.numCuerdas = numCuerdas;
    }

    public boolean isElectrica() {
        return electrica;
    }

    public void setElectrica(boolean electrica) {
        this.electrica = electrica;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    
    public void afinar() {
        System.out.println("Afinando la guitarra...");
    }

    public void tocarCuerda(int numeroCuerda) {
        System.out.println("Tocando la cuerda número " + numeroCuerda);
    }

    public void cambiarMaterial(String nuevoMaterial) {
        this.material = nuevoMaterial;
    }
}



